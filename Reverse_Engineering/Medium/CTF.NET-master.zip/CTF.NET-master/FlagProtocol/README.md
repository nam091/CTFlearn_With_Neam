# FlagProtocol

This one is all about actually CAPTURING the flag. Get the flag transmitter running and capture the flag. Solvable without reverse engineering.

- Uses .NET Core and works on Windows, Linux, (and probably macOS)
- Capture the flag without any reverse engineering (hard)
- Capture the flag by reverse engineering (medium)

### How to run
- Install the .NET Core run time for your platform
- Run `dotnet FlagProtocol.dll`

---

### FlagCapture
#### ❗ Tool to capture the flag. Keep away if you don't want to spoil the challenge! ❗